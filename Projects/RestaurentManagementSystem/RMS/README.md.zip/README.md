# Restaurant Management System

A desktop-based **Restaurant Management System (RMS)** developed using **Java, Java Swing, JDBC, and MySQL**. The application is designed to streamline restaurant operations by providing an organized interface for managing menus, customers, orders, billing, and reports.

## Project Overview

The main objective of the **Restaurant Management System** is to simplify and automate restaurant-related information and operations. It helps manage restaurant records efficiently through **Create, Read, Update, and Delete (CRUD)** operations while reducing manual work and improving day-to-day operational efficiency.

The system provides separate access levels for **Administrator** and **Staff**, allowing users to access functionality according to their responsibilities.

## Objectives

- Automate restaurant operations and reduce manual paperwork.
- Maintain restaurant information in a centralized MySQL database.
- Perform CRUD operations efficiently.
- Simplify menu, customer, order, and billing management.
- Provide a user-friendly desktop interface using Java Swing.
- Support role-based access for Administrator and Staff users.
- Improve the organization and accessibility of restaurant records.

## User Roles

### Administrator
- Manage menu items and item availability.
- Add, view, update, search, and delete customer records.
- Manage restaurant orders.
- Handle billing and payment operations.
- Access reports and analytics.
- Perform authorized administrative operations.

### Staff
- Access the Staff Dashboard.
- Process customer orders.
- Monitor kitchen and order status.
- View menu availability.
- Handle billing and payment activities.
- Use operational modules according to assigned permissions.

## Modules & Screenshots

### 1. Login
Provides the login interface for entering username and password and selecting the user role.

![Login Screen](screenshots/login.png)

### 2. Staff Dashboard
Displays an overview of restaurant activities, including pending orders, preparing orders, ready orders, pending bills, and shortcuts to daily operational modules.

![Staff Dashboard](screenshots/staff-dashboard.png)

### 3. Menu Management
Supports menu item management, including adding, viewing, updating, deleting, and searching items. Menu records include item name, category, price, and availability. Administrative actions are restricted according to role permissions.

![Menu Management](screenshots/menu-management.png)

### 4. Customer Management
Maintains customer records such as customer name, phone number, email address, and address. Supports customer record creation, viewing, updating, deletion, and searching.

![Customer Management](screenshots/customer-management.png)

### 5. Order Processing
Provides an interface to create and manage restaurant orders, including customer, item, quantity, total amount, and order status.

![Order Processing](screenshots/order-processing.png)

### 6. Billing & Invoices
Supports bill preparation and payment calculations through item management, subtotal calculation, tax calculation, grand total calculation, and payment completion.

![Billing & Invoices](screenshots/billing-invoices.png)

### 7. Reports & Analytics
Provides report selection and date-range filtering to review restaurant activity and performance using available records.

![Reports & Analytics](screenshots/reports-analytics.png)

## Technology Stack

| Technology | Purpose |
|---|---|
| **Java** | Core programming language |
| **Java Swing** | Desktop graphical user interface (GUI) |
| **MySQL** | Relational database for restaurant records |
| **JDBC** | Connectivity between Java application and MySQL |
| **IntelliJ IDEA** | Development and debugging environment |
| **Maven** | Build and dependency management, if configured |

## Database Connectivity

The application uses **MySQL** to store restaurant data and **JDBC** to connect Java components to the database. SQL operations are used to insert, retrieve, update, and delete records.

The database connection should be configured using the local database URL, username, and password. **Do not commit real database credentials to a public repository.**

## CRUD Operations

- **Create:** Add new menu, customer, order, or other records.
- **Read:** Retrieve and display stored records.
- **Update:** Modify existing records.
- **Delete:** Remove selected records.

## Getting Started

### Prerequisites
- Java JDK compatible with the project.
- MySQL Server.
- IntelliJ IDEA or another Java IDE.
- MySQL Connector/J configured in the project.
- Maven, if the project uses Maven.

### Setup
1. Clone or download the repository.
2. Create/configure the MySQL database and required tables.
3. Update the JDBC connection details in the database connection class.
4. Load project dependencies (Maven, if applicable).
5. Run the application's main class from the IDE.

> Add your actual SQL schema or database setup script to the repository if you want other developers to recreate the database easily.

## Project Structure

```text
Restaurant-Management-System/
├── src/
│   └── main/
│       ├── java/              # Java source code and Swing screens
│       └── resources/         # Application resources (if used)
├── screenshots/                # Application screenshots
├── pom.xml                     # Maven configuration (if applicable)
└── README.md
```

*Update this structure to match your actual project packages and folders.*

## Future Enhancements

- Password hashing and stronger authentication.
- Improved role and permission management.
- Enhanced input validation and exception handling.
- Export reports to PDF or Excel.
- Dashboard charts and advanced analytics.
- Database backup and restore functionality.

## Author

**Your Name**  
Java Developer | Student Project

---

*Developed as a learning project to demonstrate desktop application development, database connectivity, and restaurant operations management using Java technologies.*
